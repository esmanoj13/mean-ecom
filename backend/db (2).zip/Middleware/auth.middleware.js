// const jwt = require("jsonwebtoken");
import jwt from "jsonwebtoken";
function verifyToken(req, res, next) {
    const token = req.headers['authorization'];
    console.log("Token:", token);
    if (!token) {
        return res.status(403).json({ message: 'No token provided!' });
    }
    const secretKey = 'secretkey';
    try {
        const decoded = jwt.verify(token, secretKey);
        console.log("decoded", decoded);
        req.user = decoded;
        next();
    } catch (err) {
        console.error("Error to find token:", err);
        return res.status(401).json({ message: 'Invalid or expired token!' });
    }
}
function isAdmin(req, res, next) {
    if (req.user && req.user.isAdmin) {
        next();
    } else {
        console.log("Forbidden: Admin privileges required");
        return res.status(403).json({ message: 'Forbidden: Admin privileges required' });
    }
}

export { verifyToken, isAdmin }