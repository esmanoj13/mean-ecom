// const Product = require("./../db/product");
// const Brand = require('./../db/brand');
// const Category = require('./../db/category');
import Product from "../db/product.js";
import Brand from "../db/brand.js";
import Category from "../db/category.js";

const addProduct = async (req, res) => {
    try {
        let model = req.body;
        let product = new Product({
            ...model,
        });
        await product.save();
        res.status(201).json({
            success: true,
            message: "Product add successfully",
            product: product.toObject()
        })
    } catch (err) {
        res.status(500).json({
            success: false,
            message: "Product is not add",
            error: err.message
        })
    }
}

//This is used for the  getting all the product
// async function addproduct(model) {
//     let product = new Product({
//             name=model.name,
//             shortdescription=model.shortdescription,
//             description= model.description,
//             price= model.price,
//             discount= model.discount,
//             category= model.category,
//         ...model,
//     });
//     await product.save();
//     return product.toObject();
// }

const getProducts = async (req, res) => {
    try {
        const products = await Product.find().populate("brandId").populate("categoryId");
        if (!products) {
            return res.status(404).json({ error: "product not found" })
        }
        res.status(200).json(products);
    } catch (err) {
        console.error("error Fetching product:", err);
        return res.status(500).json({
            error: "An error occurred to get the product"
        })

    }
}
const getProduct = async (req, res) => {
    try {
        let id = req.params.id;
        const product = await Product.findById(id);
        if (!product) {
            return res.status(404).json({ error: "product not found" })
        }
        return res.status(200).json(product);
    } catch (err) {
        console.error("error Fetching product:", err);
        return res.status(500).json({
            error: "An error occurred to get the product"
        })

    }
}
const updateProduct = async (req, res) => {
    try {
        let model = req.body;
        let id = req.params.id;
        const product = await Product.findByIdAndUpdate(id, model);
        if (!product) {
            res.status(404).json({ error: "product not found" })
        }
        return res.status(201).json({
            success: true,
            message: "Product update successfully",
        });
    } catch (err) {
        console.error("error Fetching product:", err);
        return res.status(500).json({
            error: "An error occurred to update the product"
        })

    }
}
const deleteProduct = async (req, res) => {
    try {
        let id = req.params.id;
        const product = await Product.findByIdAndDelete(id);
        if (!product) {
            res.status(404).json({ error: "product not found" })
        }
        return res.status(201).json({
            success: true,
            message: "Product deleted successfully",
        });
    } catch (err) {
        console.error("error Fetching product:", err);
        return res.status(500).json({
            error: "An error occurred to delete the product"
        })

    }
}
const getNewProducts = async (req, res) => {
    try {
        const product = await Product.find({ isNewProduct: true }).populate("brandId").populate("categoryId");
        if (!product) {
            res.status(404).json({ error: "New products not found" })
        }
        return res.status(200).json(product);
    } catch (err) {
        console.error("Error to find new arrival products:", err);
        return res.status(500).json({
            error: "Error to find new arrival products"
        })
    }
}

const getFeaturedProducts = async (req, res) => {
    try {
        const product = await Product.find({ isFeatured: true }).populate("brandId").populate("categoryId");;
        if (!product) {
            res.status(404).json({ error: "Featured not found" })
        }
        // console.log(product);
        return res.status(200).json(product);
    } catch (err) {
        console.error("Error to find featured products:", err);
        return res.status(500).json({
            error: "Error to find featured products"
        })
    }
}
const mongoose = require('mongoose');
const getProductList = async (req, res) => {
    try {
        let queryParameter = {};
        const {
            searchTerm = '',
            categoryId,
            brandId,
            sortBy = 'price',
            sortOrder = 1,
            page = 1,
            pageSize = 10 } = req.query;





        if (searchTerm) {
            queryParameter.$or = [
                { name: { $regex: ".*" + searchTerm + ".*", $options: "i" } },
                { shortdescription: { $regex: ".*" + searchTerm + ".*", $options: "i" } },
            ];

        }
        console.log(queryParameter);
        const validSortFields = ["price", "name", "createdAt"]; // Add valid field names
        const sortField = validSortFields.includes(sortBy) ? sortBy : "price"; // Fallback to price
        const sortDirection = Number(sortOrder) === -1 ? -1 : 1; // Ensure valid sorting direction
        const products = await Product.find(queryParameter)
            .sort({ [sortField]: sortDirection })
            .skip((page - 1) * parseInt(pageSize))
            .limit(parseInt(pageSize));

        console.log("Request Body:", req.body);
        if (!products || products.length === 0) {
            return res.status(404).json({ error: "Search product is  not found" })
        }
        // console.log(product);
        return res.status(201).json({
            success: true,
            message: "Search product get successfully",
            products
        })

    } catch (err) {
        console.error("Error to find search products:", err);
        return res.status(500).json({
            error: "Error to find search products"
        })
    }
}


export { addProduct, getProducts, getProduct, updateProduct, deleteProduct, getFeaturedProducts, getProductList, getNewProducts }