import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class BrandService {
  constructor() {}
  private $apiURL = environment.API_URL;
  http = inject(HttpClient);
  getAllBrands() {
    return this.http.get(`${this.$apiURL}/brand`);
  }

  addBrand(name: string) {
    return this.http.post(`${this.$apiURL}/brand`, {
      name: name,
    });
  }
  deleteBrands(id: string) {
    return this.http.delete(`${this.$apiURL}/brand/${id}`);
  }
  editBrand(id: string) {
    // console.log(id);
    return this.http.get(`${this.$apiURL}/brand/${id}`);
  }

  updateBrands(id: string, name: string) {
    return this.http.put(`${this.$apiURL}/brand/${id}`, {
      name: name,
    });
  }
}
