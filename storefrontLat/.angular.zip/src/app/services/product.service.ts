import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Product } from '../types/data-types';

@Injectable({
  providedIn: 'root',
})
export class ProductService {
  constructor() {}
  private apiURL = 'http://localhost:3000/product';
  http = inject(HttpClient);

  getAllProducts() {
    return this.http.get<Product[]>(this.apiURL);
  }

  addProduct(model: Product) {
    return this.http.post<Product>(this.apiURL, model);
  }

  deleteProduct(id: string) {
    return this.http.delete<Product>(this.apiURL + '/' + id);
  }

  editProduct(id: string) {
    return this.http.get<Product>(this.apiURL + '/' + id);
  }

  updateProduct(id: string, data: Product) {
    return this.http.put<Product>(this.apiURL + '/' + id, data);
  }
}
