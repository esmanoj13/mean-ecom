import { Component, OnInit, inject } from '@angular/core';
import { AllproductsService } from '../../services/allproducts.service';
import { Product } from '../../types/data-types';
import { ActivatedRoute } from '@angular/router';
import { ProductSliderComponent } from '../product-slider/product-slider.component';

@Component({
  selector: 'app-product-list',
  standalone: true,
  imports: [ProductSliderComponent],
  templateUrl: './product-list.component.html',
  styleUrl: './product-list.component.scss',
})
export class ProductListComponent implements OnInit {
  allproductService = inject(AllproductsService);
  searchTerm: string = '';
  categoryId: string = '';
  brandId: string = '';
  sortBy: string = '';
  sortOrder: Number = 1;
  page: Number = 0;
  pageSize: Number = 10;
  products: Product[] = [];
  ActivatedRoute = inject(ActivatedRoute);
  ngOnInit(): void {
    this.ActivatedRoute.queryParams.subscribe((x: any) => {
      this.searchTerm = x.search;
      this.categoryId = x.categoryId;
      this.brandId = x.brandId;
    });
    this.getsearchProducts();
  }
  getsearchProducts() {
    this.allproductService
      .getSearchProducts(
        this.searchTerm,
        this.categoryId,
        this.brandId,
        this.sortBy,
        this.sortOrder,
        this.page,
        this.pageSize
      )
      .subscribe((data) => {
        this.products = data;
        console.log('data:' + data);
      });
    console.log(this.products);
  }
}
