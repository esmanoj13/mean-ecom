import { Component, inject, OnInit } from '@angular/core';
import { CategoryService } from '../../services/category.service';
import { Category } from '../../types/data-types';
import { Router, RouterModule } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { FormsModule } from '@angular/forms';
@Component({
  selector: 'app-header',
  standalone: true,
  imports: [RouterModule, FormsModule],
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss',
})
export class HeaderComponent implements OnInit {
  searchTerm = '';
  router = inject(Router);
  ecommCompany: string = 'EasyMart';
  categories: Category[] = [];
  authService = inject(AuthService);
  categoryService = inject(CategoryService);
  ngOnInit(): void {
    this.categoryService.getcategories().subscribe((data) => {
  
      
      this.categories = data;
    });
  }
  searchitem(event: any) {
    if (event.target.value) {
      console.log(event.target.value);
      this.router.navigateByUrl('/product?search=' + event.target.value);
    }
  }
  searchCategory(id: string, name: string) {
    this.searchTerm = '';
    this.router.navigateByUrl('/product?category=' + name);
  }
  searchBrand(id: string, name: string) {
    this.searchTerm = '';
    this.router.navigateByUrl('/product?brand=' + name);
  }
  logout() {
    this.authService.logout();
    this.router.navigateByUrl('/login');
  }
}
