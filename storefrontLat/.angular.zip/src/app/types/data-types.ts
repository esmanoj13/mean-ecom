export interface Category {
  _id?: string;
  name: string;
}
export interface Brand {
  _id?: string;
  name: string;
}

export interface Product {
  _id?: string;
  name: string;
  shortdescription: string;
  description: string;
  categoryId: string;
  brandId: string;
  price: number;
  discount: number;
  isFeatured: boolean;
  isNewProduct: boolean;
  image: string[];
}

export interface Register {
  _id?: string;
  name: string;
  email: string;
  password: string;
}
export interface Login {
  _id?: string;
  email: string;
  password: string;
}
